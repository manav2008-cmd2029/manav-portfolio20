# Manav M | Portfolio 2026

A neo-brutalist portfolio built as a horizontal slideshow deck. Plain HTML, CSS and JavaScript: no build step, no dependencies.

## Files

- `index.html` holds the six slides
- `style.css` holds the design system (colors are variables at the top)
- `script.js` handles buttons, dots, arrow keys, touch swipe and `#3`-style slide links

## Replace before publishing

Search `index.html` for `TODO` and `[` to find every placeholder:

- Slide 3, second card: your school details
- Slide 4: your real skills
- Slide 5: your projects and their links
- Slide 6: email, GitHub and LinkedIn links

## Run locally

Open `index.html` in a browser, or run `npx serve` in this folder.

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial portfolio"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Deploy on Vercel

1. Sign in at vercel.com and choose **Add New → Project**.
2. Import the GitHub repository.
3. Set **Framework Preset** to **Other**. Leave the build command and output directory empty.
4. Click **Deploy**. Every later `git push` redeploys automatically.

## Controls

- Previous and Next buttons, or the ← and → keys
- Click a dot to jump to a slide; Home and End go to the first and last
- Swipe left or right on a phone
