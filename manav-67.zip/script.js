(() => {
  const deck = document.getElementById('deck');
  const track = document.getElementById('track');
  const slides = [...track.children];
  const dotsEl = document.getElementById('dots');
  const countEl = document.getElementById('count');
  const prev = document.getElementById('prev');
  const next = document.getElementById('next');
  const n = slides.length;
  const pad = v => String(v).padStart(2, '0');
  let i = 0;

  // Stagger index for each slide's reveal items, and one dot per slide
  slides.forEach((slide, k) => {
    slide.querySelectorAll('.reveal').forEach((el, j) => el.style.setProperty('--i', j));
    const dot = document.createElement('button');
    dot.className = 'dot';
    dot.title = slide.dataset.title;
    dot.setAttribute('aria-label', `Go to slide ${k + 1}: ${slide.dataset.title}`);
    dot.addEventListener('click', () => go(k));
    dotsEl.append(dot);
  });
  const dots = [...dotsEl.children];

  function go(k) {
    i = Math.max(0, Math.min(n - 1, k));
    track.style.transform = `translateX(-${i * 100}%)`;
    slides.forEach((s, j) => {
      s.classList.toggle('active', j === i);
      s.inert = j !== i;            // keep off-screen slides out of the tab order
      if (j !== i) s.scrollTop = 0;
    });
    dots.forEach((d, j) => {
      d.classList.toggle('on', j === i);
      d.toggleAttribute('aria-current', j === i);
    });
    countEl.textContent = `${pad(i + 1)} / ${pad(n)}`;
    prev.disabled = i === 0;
    next.disabled = i === n - 1;
    history.replaceState(null, '', `#${i + 1}`);
  }

  prev.addEventListener('click', () => go(i - 1));
  next.addEventListener('click', () => go(i + 1));
  document.querySelectorAll('[data-go]').forEach(el =>
    el.addEventListener('click', () => go(Number(el.dataset.go) - 1)));

  document.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') go(i + 1);
    else if (e.key === 'ArrowLeft') go(i - 1);
    else if (e.key === 'Home') go(0);
    else if (e.key === 'End') go(n - 1);
  });

  // Touch swipe: only clearly horizontal gestures change slides
  let x0 = 0, y0 = 0;
  deck.addEventListener('touchstart', e => {
    x0 = e.touches[0].clientX;
    y0 = e.touches[0].clientY;
  }, { passive: true });
  deck.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - x0;
    const dy = e.changedTouches[0].clientY - y0;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) go(i + (dx < 0 ? 1 : -1));
  }, { passive: true });

  window.addEventListener('hashchange', () => go((parseInt(location.hash.slice(1), 10) || 1) - 1));

  // Start on the slide in the URL (e.g. /#3), without the slide-in animation
  track.style.transition = 'none';
  go((parseInt(location.hash.slice(1), 10) || 1) - 1);
  requestAnimationFrame(() => requestAnimationFrame(() => (track.style.transition = '')));
})();
